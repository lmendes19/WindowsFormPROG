﻿namespace WindowsFormsApp10
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_VA = new System.Windows.Forms.Label();
            this.LbMensagem = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_VB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.text_Resultado = new System.Windows.Forms.TextBox();
            this.text_VA = new System.Windows.Forms.TextBox();
            this.BtLimpar = new System.Windows.Forms.Button();
            this.BtCalcular = new System.Windows.Forms.Button();
            this.text_VB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_VA
            // 
            this.lbl_VA.AutoSize = true;
            this.lbl_VA.Location = new System.Drawing.Point(29, 49);
            this.lbl_VA.Name = "lbl_VA";
            this.lbl_VA.Size = new System.Drawing.Size(121, 13);
            this.lbl_VA.TabIndex = 42;
            this.lbl_VA.Text = "Digite o seu peso em kg";
            // 
            // LbMensagem
            // 
            this.LbMensagem.AutoSize = true;
            this.LbMensagem.Location = new System.Drawing.Point(29, 323);
            this.LbMensagem.Name = "LbMensagem";
            this.LbMensagem.Size = new System.Drawing.Size(0, 13);
            this.LbMensagem.TabIndex = 41;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 40;
            this.label3.Text = "Aqui está o resultado";
            // 
            // lbl_VB
            // 
            this.lbl_VB.AutoSize = true;
            this.lbl_VB.Location = new System.Drawing.Point(29, 110);
            this.lbl_VB.Name = "lbl_VB";
            this.lbl_VB.Size = new System.Drawing.Size(128, 13);
            this.lbl_VB.TabIndex = 39;
            this.lbl_VB.Text = "Digite sua altura (Ex: 180)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Obtenha o seu IMC a partir desse software";
            // 
            // text_Resultado
            // 
            this.text_Resultado.Location = new System.Drawing.Point(32, 283);
            this.text_Resultado.Name = "text_Resultado";
            this.text_Resultado.Size = new System.Drawing.Size(274, 20);
            this.text_Resultado.TabIndex = 37;
            // 
            // text_VA
            // 
            this.text_VA.Location = new System.Drawing.Point(32, 75);
            this.text_VA.Name = "text_VA";
            this.text_VA.Size = new System.Drawing.Size(100, 20);
            this.text_VA.TabIndex = 36;
            // 
            // BtLimpar
            // 
            this.BtLimpar.Location = new System.Drawing.Point(119, 192);
            this.BtLimpar.Name = "BtLimpar";
            this.BtLimpar.Size = new System.Drawing.Size(66, 38);
            this.BtLimpar.TabIndex = 35;
            this.BtLimpar.Text = "Limpar";
            this.BtLimpar.UseVisualStyleBackColor = true;
            this.BtLimpar.Click += new System.EventHandler(this.BtLimpar_Click);
            // 
            // BtCalcular
            // 
            this.BtCalcular.Location = new System.Drawing.Point(32, 173);
            this.BtCalcular.Name = "BtCalcular";
            this.BtCalcular.Size = new System.Drawing.Size(81, 57);
            this.BtCalcular.TabIndex = 34;
            this.BtCalcular.Text = "Calcular";
            this.BtCalcular.UseVisualStyleBackColor = true;
            this.BtCalcular.Click += new System.EventHandler(this.BtCalcular_Click);
            // 
            // text_VB
            // 
            this.text_VB.Location = new System.Drawing.Point(32, 136);
            this.text_VB.Name = "text_VB";
            this.text_VB.Size = new System.Drawing.Size(100, 20);
            this.text_VB.TabIndex = 33;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 369);
            this.Controls.Add(this.lbl_VA);
            this.Controls.Add(this.LbMensagem);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_VB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.text_Resultado);
            this.Controls.Add(this.text_VA);
            this.Controls.Add(this.BtLimpar);
            this.Controls.Add(this.BtCalcular);
            this.Controls.Add(this.text_VB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_VA;
        private System.Windows.Forms.Label LbMensagem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_VB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_Resultado;
        private System.Windows.Forms.TextBox text_VA;
        private System.Windows.Forms.Button BtLimpar;
        private System.Windows.Forms.Button BtCalcular;
        private System.Windows.Forms.TextBox text_VB;
    }
}


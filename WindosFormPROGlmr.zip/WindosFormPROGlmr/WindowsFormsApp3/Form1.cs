﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
            if (TbDiagonal1.Text != "") 
            {
                float resultado = float.Parse(TbDiagonal1.Text) * float.Parse(TbDiagonal1.Text) / 2;
                TbArea.Text = resultado.ToString();
                LbMensagem.Text = "Calculo efetuado!!";
            }
            else
            {
                LbMensagem.Text = "Digite os respectivos valores para efetuar o calculo...";
            }

        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            TbDiagonal1.Text = null;
            LbMensagem.Text = null;
            TbArea.Text = null;
        }
    }
}

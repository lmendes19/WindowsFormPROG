﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            text_VA.Text = null;
            text_VB.Text = null;
            LbMensagem.Text = null;
            text_Resultado.Text = null;
        }

        private void BtComparar_Click(object sender, EventArgs e)
        {
            if ((text_VA.Text != "") && (text_VB.Text != ""))
            {
              
                float resultado = (float.Parse(text_VA.Text) * float.Parse(text_VB.Text));

                if (resultado > 100)
                {
                    text_Resultado.Text = "Terreno grande";
                }
                else
                {
                    text_Resultado.Text = "Terreno pequeno";
                }
                LbMensagem.Text = "Comparação efetuado!!";
            }
            else
            {
                LbMensagem.Text = "Digite os respectivos valores para efetuar a comparação...";
            }
        }
    }
}

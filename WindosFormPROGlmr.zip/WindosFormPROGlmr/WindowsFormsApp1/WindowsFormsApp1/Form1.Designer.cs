﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbinicio = new System.Windows.Forms.Label();
            this.lbbase = new System.Windows.Forms.Label();
            this.lbaltura = new System.Windows.Forms.Label();
            this.lbresultado = new System.Windows.Forms.Label();
            this.TbBase = new System.Windows.Forms.TextBox();
            this.TbAltura = new System.Windows.Forms.TextBox();
            this.btcalcular = new System.Windows.Forms.Button();
            this.TbArea = new System.Windows.Forms.TextBox();
            this.btlimpar = new System.Windows.Forms.Button();
            this.LbMensagem = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbinicio
            // 
            this.lbinicio.AutoSize = true;
            this.lbinicio.Location = new System.Drawing.Point(12, 9);
            this.lbinicio.Name = "lbinicio";
            this.lbinicio.Size = new System.Drawing.Size(311, 13);
            this.lbinicio.TabIndex = 0;
            this.lbinicio.Text = "Obtenha o valor da área do seu retangulo a partir deste software";
            this.lbinicio.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbbase
            // 
            this.lbbase.AutoSize = true;
            this.lbbase.Location = new System.Drawing.Point(41, 45);
            this.lbbase.Name = "lbbase";
            this.lbbase.Size = new System.Drawing.Size(110, 13);
            this.lbbase.TabIndex = 1;
            this.lbbase.Text = "Digite o valor da base";
            // 
            // lbaltura
            // 
            this.lbaltura.AutoSize = true;
            this.lbaltura.Location = new System.Drawing.Point(41, 120);
            this.lbaltura.Name = "lbaltura";
            this.lbaltura.Size = new System.Drawing.Size(113, 13);
            this.lbaltura.TabIndex = 2;
            this.lbaltura.Text = "Digite o valor da altura";
            // 
            // lbresultado
            // 
            this.lbresultado.AutoSize = true;
            this.lbresultado.Location = new System.Drawing.Point(41, 246);
            this.lbresultado.Name = "lbresultado";
            this.lbresultado.Size = new System.Drawing.Size(128, 13);
            this.lbresultado.TabIndex = 3;
            this.lbresultado.Text = "Aqui está o valor da área:";
            // 
            // TbBase
            // 
            this.TbBase.Location = new System.Drawing.Point(44, 76);
            this.TbBase.Name = "TbBase";
            this.TbBase.Size = new System.Drawing.Size(100, 20);
            this.TbBase.TabIndex = 4;
            // 
            // TbAltura
            // 
            this.TbAltura.Location = new System.Drawing.Point(44, 154);
            this.TbAltura.Name = "TbAltura";
            this.TbAltura.Size = new System.Drawing.Size(100, 20);
            this.TbAltura.TabIndex = 5;
            // 
            // btcalcular
            // 
            this.btcalcular.Location = new System.Drawing.Point(44, 180);
            this.btcalcular.Name = "btcalcular";
            this.btcalcular.Size = new System.Drawing.Size(100, 63);
            this.btcalcular.TabIndex = 6;
            this.btcalcular.Text = "Calcular";
            this.btcalcular.UseVisualStyleBackColor = true;
            this.btcalcular.Click += new System.EventHandler(this.btcalcular_Click);
            // 
            // TbArea
            // 
            this.TbArea.Location = new System.Drawing.Point(44, 271);
            this.TbArea.Name = "TbArea";
            this.TbArea.ReadOnly = true;
            this.TbArea.Size = new System.Drawing.Size(100, 20);
            this.TbArea.TabIndex = 7;
            // 
            // btlimpar
            // 
            this.btlimpar.Location = new System.Drawing.Point(150, 199);
            this.btlimpar.Name = "btlimpar";
            this.btlimpar.Size = new System.Drawing.Size(73, 44);
            this.btlimpar.TabIndex = 8;
            this.btlimpar.Text = "Limpar";
            this.btlimpar.UseVisualStyleBackColor = true;
            this.btlimpar.Click += new System.EventHandler(this.btlimpar_Click);
            // 
            // LbMensagem
            // 
            this.LbMensagem.AutoSize = true;
            this.LbMensagem.Location = new System.Drawing.Point(44, 299);
            this.LbMensagem.Name = "LbMensagem";
            this.LbMensagem.Size = new System.Drawing.Size(0, 13);
            this.LbMensagem.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 324);
            this.Controls.Add(this.LbMensagem);
            this.Controls.Add(this.btlimpar);
            this.Controls.Add(this.TbArea);
            this.Controls.Add(this.btcalcular);
            this.Controls.Add(this.TbAltura);
            this.Controls.Add(this.TbBase);
            this.Controls.Add(this.lbresultado);
            this.Controls.Add(this.lbaltura);
            this.Controls.Add(this.lbbase);
            this.Controls.Add(this.lbinicio);
            this.Name = "Form1";
            this.Text = "Area do retangulo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbinicio;
        private System.Windows.Forms.Label lbbase;
        private System.Windows.Forms.Label lbaltura;
        private System.Windows.Forms.Label lbresultado;
        private System.Windows.Forms.TextBox TbBase;
        private System.Windows.Forms.TextBox TbAltura;
        private System.Windows.Forms.Button btcalcular;
        private System.Windows.Forms.TextBox TbArea;
        private System.Windows.Forms.Button btlimpar;
        private System.Windows.Forms.Label LbMensagem;
    }
}


﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtCalcular = new System.Windows.Forms.Button();
            this.BtLimpar = new System.Windows.Forms.Button();
            this.TbMilhas = new System.Windows.Forms.TextBox();
            this.TbQuilometros = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LbMensagem = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtCalcular
            // 
            this.BtCalcular.Location = new System.Drawing.Point(31, 127);
            this.BtCalcular.Name = "BtCalcular";
            this.BtCalcular.Size = new System.Drawing.Size(107, 66);
            this.BtCalcular.TabIndex = 0;
            this.BtCalcular.Text = "Calcular";
            this.BtCalcular.UseVisualStyleBackColor = true;
            this.BtCalcular.Click += new System.EventHandler(this.BtCalcular_Click);
            // 
            // BtLimpar
            // 
            this.BtLimpar.Location = new System.Drawing.Point(144, 145);
            this.BtLimpar.Name = "BtLimpar";
            this.BtLimpar.Size = new System.Drawing.Size(83, 48);
            this.BtLimpar.TabIndex = 1;
            this.BtLimpar.Text = "Limpar";
            this.BtLimpar.UseVisualStyleBackColor = true;
            this.BtLimpar.Click += new System.EventHandler(this.BtLimpar_Click);
            // 
            // TbMilhas
            // 
            this.TbMilhas.Location = new System.Drawing.Point(31, 92);
            this.TbMilhas.Name = "TbMilhas";
            this.TbMilhas.Size = new System.Drawing.Size(154, 20);
            this.TbMilhas.TabIndex = 2;
            // 
            // TbQuilometros
            // 
            this.TbQuilometros.Location = new System.Drawing.Point(31, 234);
            this.TbQuilometros.Name = "TbQuilometros";
            this.TbQuilometros.Size = new System.Drawing.Size(154, 20);
            this.TbQuilometros.TabIndex = 3;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(28, 34);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(312, 13);
            this.label.TabIndex = 4;
            this.label.Text = "Converta milhas marítimas em quilometros a partir desse software";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Aqui está o valor em quilometros:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Digite o valor em milhas maritimas";
            // 
            // LbMensagem
            // 
            this.LbMensagem.AutoSize = true;
            this.LbMensagem.Location = new System.Drawing.Point(31, 276);
            this.LbMensagem.Name = "LbMensagem";
            this.LbMensagem.Size = new System.Drawing.Size(0, 13);
            this.LbMensagem.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 292);
            this.Controls.Add(this.LbMensagem);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label);
            this.Controls.Add(this.TbQuilometros);
            this.Controls.Add(this.TbMilhas);
            this.Controls.Add(this.BtLimpar);
            this.Controls.Add(this.BtCalcular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtCalcular;
        private System.Windows.Forms.Button BtLimpar;
        private System.Windows.Forms.TextBox TbMilhas;
        private System.Windows.Forms.TextBox TbQuilometros;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LbMensagem;
    }
}


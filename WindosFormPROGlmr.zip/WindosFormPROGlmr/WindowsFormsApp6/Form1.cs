﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
            if (TbMilhas.Text != "") 
            {
                float resultado = float.Parse(TbMilhas.Text) * 1852;
                TbQuilometros.Text = resultado.ToString();
                LbMensagem.Text = "Calculo efetuado!!";
            }
            else
            {
                LbMensagem.Text = "Digite os respectivos valores para efetuar o calculo...";
            }
        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            TbMilhas.Text = null;
            TbQuilometros.Text = null;
            LbMensagem.Text = null;
        }
    }
}

﻿namespace WindowsFormsApp6
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbMensagem = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.TbReais = new System.Windows.Forms.TextBox();
            this.TbDolares = new System.Windows.Forms.TextBox();
            this.BtLimpar = new System.Windows.Forms.Button();
            this.BtCalcular = new System.Windows.Forms.Button();
            this.TbCotacao = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LbMensagem
            // 
            this.LbMensagem.AutoSize = true;
            this.LbMensagem.Location = new System.Drawing.Point(28, 327);
            this.LbMensagem.Name = "LbMensagem";
            this.LbMensagem.Size = new System.Drawing.Size(0, 13);
            this.LbMensagem.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Resultado em reais: R$";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(25, 26);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(194, 13);
            this.label.TabIndex = 12;
            this.label.Text = "Digite o Valor da Cotação do Dólar: R$ ";
            // 
            // TbReais
            // 
            this.TbReais.Location = new System.Drawing.Point(28, 282);
            this.TbReais.Name = "TbReais";
            this.TbReais.Size = new System.Drawing.Size(154, 20);
            this.TbReais.TabIndex = 11;
            // 
            // TbDolares
            // 
            this.TbDolares.Location = new System.Drawing.Point(28, 129);
            this.TbDolares.Name = "TbDolares";
            this.TbDolares.Size = new System.Drawing.Size(154, 20);
            this.TbDolares.TabIndex = 10;
            // 
            // BtLimpar
            // 
            this.BtLimpar.Location = new System.Drawing.Point(136, 186);
            this.BtLimpar.Name = "BtLimpar";
            this.BtLimpar.Size = new System.Drawing.Size(83, 48);
            this.BtLimpar.TabIndex = 9;
            this.BtLimpar.Text = "Limpar";
            this.BtLimpar.UseVisualStyleBackColor = true;
            this.BtLimpar.Click += new System.EventHandler(this.BtLimpar_Click);
            // 
            // BtCalcular
            // 
            this.BtCalcular.Location = new System.Drawing.Point(28, 168);
            this.BtCalcular.Name = "BtCalcular";
            this.BtCalcular.Size = new System.Drawing.Size(107, 66);
            this.BtCalcular.TabIndex = 8;
            this.BtCalcular.Text = "Calcular";
            this.BtCalcular.UseVisualStyleBackColor = true;
            this.BtCalcular.Click += new System.EventHandler(this.BtCalcular_Click);
            // 
            // TbCotacao
            // 
            this.TbCotacao.Location = new System.Drawing.Point(28, 57);
            this.TbCotacao.Name = "TbCotacao";
            this.TbCotacao.Size = new System.Drawing.Size(154, 20);
            this.TbCotacao.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Digite um Valor em Dólares: US$";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 357);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TbCotacao);
            this.Controls.Add(this.LbMensagem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label);
            this.Controls.Add(this.TbReais);
            this.Controls.Add(this.TbDolares);
            this.Controls.Add(this.BtLimpar);
            this.Controls.Add(this.BtCalcular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LbMensagem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox TbReais;
        private System.Windows.Forms.TextBox TbDolares;
        private System.Windows.Forms.Button BtLimpar;
        private System.Windows.Forms.Button BtCalcular;
        private System.Windows.Forms.TextBox TbCotacao;
        private System.Windows.Forms.Label label3;
    }
}

